package view;

import javax.swing.*;

public class JFCliente extends JFrame {
    public JFCliente(){}
    private JPanel jPanel1;
    private void initComponents(){
        JPanel jPanel1 = new JPanel();
    }


}
