package view;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class FormLogin extends JFrame {
    JPanel pnlLogin;
    JLabel lblLogin, lblSenha;
    JTextField txtLogin, txtSenha;
    JButton btnEntrar, btnCadastrarNovo;

    public FormLogin(){
        setTitle("Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Painel de Login
        pnlLogin = new JPanel(new GridLayout(2, 2, 5, 5));
        lblLogin = new JLabel("Login: ");
        txtLogin = new JTextField(10);
        lblSenha = new JLabel("Senha");
        txtSenha = new JTextField(10);

        pnlLogin.add(lblLogin);
        pnlLogin.add(txtLogin);
        pnlLogin.add(lblSenha);
        pnlLogin.add(txtSenha);

        // Botões
        JPanel panelBotoes = new JPanel(new GridLayout(2, 1, 5, 5));
        TitledBorder tituloBotoes = new TitledBorder(" ");
        panelBotoes.setBorder(tituloBotoes);

        btnEntrar = new JButton("Entrar");
        btnCadastrarNovo = new JButton("Cadastrar Novo Usuário");

        panelBotoes.add(btnEntrar);
        panelBotoes.add(btnCadastrarNovo);

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.add(pnlLogin, BorderLayout.CENTER);
        panelPrincipal.add(panelBotoes, BorderLayout.SOUTH);

        add(panelPrincipal);

        pack();
        setVisible(true);

        btnCadastrarNovo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FormUsuario usuario = new FormUsuario();
                usuario.setVisible(true);

                dispose();
            }
        });

        btnEntrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnEntrar.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Connection conex = DriverManager.getConnection("jdbc:mysql://localhost:3306/prova", "root", "");
                            String banco = "SELECT id, nome, login, senha, email FROM usuario WHERE login = ? AND senha = ?";
                            PreparedStatement pst = conex.prepareStatement(banco);
                            pst.setString(1, txtLogin.getText());
                            pst.setString(2, txtSenha.getText());

                            ResultSet rs = pst.executeQuery();

                            if(rs.next()) {
                                JOptionPane.showMessageDialog(null, "Acesso Autorizado");
                            } else {
                                JOptionPane.showMessageDialog(null, "Acesso Negado", "Erro", JOptionPane.ERROR_MESSAGE);
                            }

                            conex.close();
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(null, "Erro ao conectar com o banco de dados", "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                });
            }
        });

    }
}