package view;

import model.Livro;
import uteis.BdCliente;
import uteis.BdLivro;
import java.sql.SQLException;

public class Biblioteca {
    public static void main(String[] args) throws SQLException {
        FormCliente formCliente = new FormCliente();
        formCliente.setVisible(true);
        //BdCliente cliente = new BdCliente();
        //cliente.adicionarCliente();
        //JFCliente janela = new JFCliente();
        //janela.setVisible(true);
        //Livro livro1 = new Livro(1, "Senhor dos Aneis", "pong", 1, 2050, "s");
        //BdLivro conexao = new BdLivro();
        //conexao.adicionarLivro(livro1);
    }
}
