package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FormCliente extends JFrame {
    JPanel pnlPrincipal, pnlPesquisar, pnlClientes, pnlDadosClientes, pnlBotoesClientes;
    JLabel lblPesquisar;
    JTextField txtPesquisar;
    JButton btnPesquisar, btnExcluir;
    JTable tblPesquisar;
    public FormCliente() {
        setTitle("Cadastro de Cliente");
        setBounds(300,90,900,600);

        pnlPrincipal = new JPanel(new GridLayout(2,1,5,5));
        pnlPrincipal.setBackground(Color.BLUE);

        pnlPesquisar = new JPanel();
        pnlPesquisar.setBounds(300,90,900,300);
        pnlPesquisar.setBackground(Color.WHITE);
        lblPesquisar = new JLabel("Nome:");
        txtPesquisar = new JTextField();
        txtPesquisar.setColumns(60);
        btnPesquisar = new JButton("Pesquisar");

        Object[][] dados = {
                {"Id", "Nome", "Data Nascimento", "Sexo", "Endereço", "Fone"},
                {1, "Pietro", "09/03/1994", "M", "Rua das Oliveiras", "434343433"},
                {2, "Pong", "09/03/2004", "M", "Rua das Maconheiras", "123456789"},
                {3, "Thiago", "09/03/2007", "M", "Rua das Bananeiras", "434343433"},
                {4, "Pietro", "09/03/1994", "M", "Rua das Oliveiras", "434343433"},
                {5, "Pong", "09/03/2004", "M", "Rua das Maconheiras", "123456789"},
                {6, "Thiago", "09/03/2007", "M", "Rua das Bananeiras", "434343433"},
        };

        String [] colunas = {"Id", "Nome", "Data Nascimento", "Sexo", "Endereço", "Fone"};

        tblPesquisar = new JTable(dados, colunas);

        tblPesquisar.getColumnModel().getColumn(0).setPreferredWidth(20);
        tblPesquisar.getColumnModel().getColumn(0).setResizable(false);
        tblPesquisar.getColumnModel().getColumn(1).setPreferredWidth(250);
        tblPesquisar.getColumnModel().getColumn(1).setResizable(false);
        tblPesquisar.getColumnModel().getColumn(2).setPreferredWidth(250);
        tblPesquisar.getColumnModel().getColumn(2).setResizable(false);
        tblPesquisar.getColumnModel().getColumn(3).setPreferredWidth(20);
        tblPesquisar.getColumnModel().getColumn(3).setResizable(false);
        tblPesquisar.getColumnModel().getColumn(4).setPreferredWidth(250);
        tblPesquisar.getColumnModel().getColumn(4).setResizable(false);
        tblPesquisar.getColumnModel().getColumn(5).setPreferredWidth(80);
        tblPesquisar.getColumnModel().getColumn(5).setResizable(false);

        pnlClientes = new JPanel(new GridLayout(0,2));
        pnlClientes.setBackground(Color.PINK);

        pnlDadosClientes = new JPanel();
        pnlDadosClientes.setSize(600,180);
        pnlDadosClientes.setBackground(Color.GREEN);
        pnlBotoesClientes = new JPanel();
        pnlBotoesClientes.setSize(290,180);
        pnlBotoesClientes.setBackground(Color.BLACK);

        btnExcluir = new JButton("Excluir");

        pnlPrincipal.add(pnlPesquisar);
        pnlPrincipal.add(pnlClientes);

        pnlPesquisar.add(lblPesquisar);
        pnlPesquisar.add(txtPesquisar);
        pnlPesquisar.add(btnPesquisar);
        pnlPesquisar.add(tblPesquisar);
        pnlClientes.add(pnlDadosClientes, BorderLayout.CENTER);
        pnlClientes.add(pnlBotoesClientes, BorderLayout.EAST);
        pnlBotoesClientes.add(btnExcluir);

        getContentPane().add(pnlPrincipal);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }


}
