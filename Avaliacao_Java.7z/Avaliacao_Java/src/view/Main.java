package view;

import Banco_de_Dados.Conexão;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        //Conexão conexao = new Conexão();
        //conexao.getConexao();

        FormLogin login = new FormLogin();
        login.setVisible(true);

        //FormUsuario usuario = new FormUsuario();
        //usuario.setVisible(true);

    }
}
