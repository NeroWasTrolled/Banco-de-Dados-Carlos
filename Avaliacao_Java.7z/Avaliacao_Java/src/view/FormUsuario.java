package view;

import Banco_de_Dados.BdCadastro;
import Model.CadastroUsuario;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class FormUsuario extends JFrame {
    JPanel pnlCadastro;
    JLabel lblNome, lblLogin, lblSenha, lblEmail;
    JTextField txtNome, txtLogin, txtSenha, txtEmail;
    JButton btnSalvar, btnVoltar;

    public FormUsuario(){
        setTitle("Cadastrar Novo Usuário");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Painel de Cadastro
        pnlCadastro = new JPanel(new GridLayout(5, 2, 5, 5));
        lblNome = new JLabel("Nome: ");
        txtNome = new JTextField(10);
        lblLogin = new JLabel("Login: ");
        txtLogin = new JTextField(10);
        lblSenha = new JLabel("Senha: ");
        txtSenha = new JTextField(10);
        lblEmail = new JLabel("Email: ");
        txtEmail = new JTextField(10);

        pnlCadastro.add(lblNome);
        pnlCadastro.add(txtNome);
        pnlCadastro.add(lblLogin);
        pnlCadastro.add(txtLogin);
        pnlCadastro.add(lblSenha);
        pnlCadastro.add(txtSenha);
        pnlCadastro.add(lblEmail);
        pnlCadastro.add(txtEmail);

        // Botões
        JPanel panelBotoes = new JPanel(new GridLayout(2, 1, 5, 5));
        TitledBorder tituloBotoes = new TitledBorder(" ");
        panelBotoes.setBorder(tituloBotoes);

        btnSalvar = new JButton("Salvar");
        btnVoltar = new JButton("Voltar");

        panelBotoes.add(btnSalvar);
        panelBotoes.add(btnVoltar);

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.add(pnlCadastro, BorderLayout.CENTER);
        panelPrincipal.add(panelBotoes, BorderLayout.SOUTH);

        add(panelPrincipal);

        pack();
        setVisible(true);

        btnVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FormLogin login = new FormLogin();
                login.setVisible(true);

                dispose();
            }
        });

        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    CadastroUsuario usuario = new CadastroUsuario();
                    usuario.setNome(txtNome.getText());
                    usuario.setLogin(txtLogin.getText());
                    usuario.setSenha(txtSenha.getText());
                    usuario.setEmail(txtEmail.getText());

                    BdCadastro bdCadastro = new BdCadastro();
                    bdCadastro.addUsuario(usuario.getNome(), usuario.getLogin(), usuario.getSenha(), usuario.getEmail());

                    JOptionPane.showMessageDialog(null, "Usuário cadastrado com sucesso!");
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}