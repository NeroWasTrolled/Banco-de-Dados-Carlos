package Banco_de_Dados;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BdCadastro {

    private Connection conex;

    public BdCadastro() throws SQLException{
        this.conex = Conexão.getConexao();
    }
    public void addUsuario(String nome, String login, String senha, String email) throws SQLException{
        String banco = "INSERT INTO usuario(nome, login, senha, email)"
                + "VALUES (?,?,?,?)";
        PreparedStatement stmt;
        stmt = this.conex.prepareStatement(banco);

        stmt.setString(1, nome);
        stmt.setString(2, login);
        stmt.setString(3, senha);
        stmt.setString(4, email);

        stmt.execute();
        stmt.close();
    }

}
