package view;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Dictionary;

public class FormLivro implements ActionListener{
    JButton btnExcluir = new JButton("Excluir");
    JButton btnAlterar = new JButton("Alterar");
    JButton btnNovo = new JButton("Novo");
    JButton btnCadastrar = new JButton("Cadastrar");
    JButton btnSair = new JButton("Sair");
    JButton Cadastrar;
    public FormLivro() {
        JFrame frame = new JFrame();
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        //Container "Pesquisar livro"
        JPanel panelPesquisar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        TitledBorder tituloPesquisar = new TitledBorder("Pesquisar Livro");
        panelPesquisar.setBorder(tituloPesquisar);
        JLabel labelNome = new JLabel("Nome: ");
        JTextField inputNome = new JTextField(50);
        JButton btnPesquisar = new JButton("Pesquisar");

        panelPesquisar.add(labelNome);
        panelPesquisar.add(inputNome);
        panelPesquisar.add(btnPesquisar);
        frame.add(panelPesquisar, BorderLayout.NORTH);

        //Grid de Livros
        String [] colunas = {"ID", "Exemplar", "Autor", "Edição", "Ano", "Disponbilidade"};
        DefaultTableModel model = new DefaultTableModel(colunas, 1);
        JTable tabelaLivros = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(tabelaLivros);
        frame.add(scrollPane, BorderLayout.CENTER);

        //Dados dos livros
        JPanel panelDados = new JPanel(new GridBagLayout());
        TitledBorder tituloDados = new TitledBorder("Dados Livros");
        panelDados.setBorder(tituloDados);
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.fill = GridBagConstraints.HORIZONTAL;
        String [] labels = {"ID: ", "Exemplar:", "Autor:", "Edição:", "Ano:", "Disponibilidade: "};
        int[] tamanhoCampo = {5, 20, 10, 14, 30, 15};

        for (int i = 0; i< tamanhoCampo.length;i++){
            gbc.gridx = 0;
            gbc.gridy = i;
            gbc.weightx = 1;
            panelDados.add(new JLabel(labels[i]), gbc);

            gbc.gridx = 1;
            gbc.weightx= 1;
            panelDados.add(new JTextField(tamanhoCampo[i]), gbc);
        }

        //Botões a direita do formulário
        JPanel panelBotoes = new JPanel(new GridLayout(5, 1));
        TitledBorder tituloBotoes = new TitledBorder(" ");
        panelBotoes.setBorder(tituloBotoes);

        btnExcluir.addActionListener(this);
        btnAlterar.addActionListener(this);
        btnNovo.addActionListener(this);
        btnCadastrar.addActionListener(this);
        btnSair.addActionListener(this);

        panelBotoes.add(btnExcluir);
        panelBotoes.add(btnAlterar);
        panelBotoes.add(btnNovo);
        panelBotoes.add(btnCadastrar);
        panelBotoes.add(btnSair);

        JPanel panelFormulario = new JPanel(new BorderLayout());
        panelFormulario.add(panelDados, BorderLayout.CENTER);
        panelFormulario.add(panelBotoes, BorderLayout.EAST);

        frame.add(panelFormulario, BorderLayout.SOUTH);

        frame.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println();

    }
}