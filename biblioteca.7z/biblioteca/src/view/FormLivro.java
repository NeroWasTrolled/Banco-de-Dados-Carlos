package view;
import model.Livro;
import uteis.BdLivro;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class FormLivro {
    JButton btnCadastrar, btnExcluir, btnNovo, btnSair, btnAlterar;
    JLabel lblExemplar, lblID, lblAutor, lblEdicao, lblAno, lblDisponibilidade;
    JTextField txtExemplar, txtID, txtAutor, txtEdicao, txtAno, txtDisponibilidade;
    public FormLivro() {
        JFrame frame = new JFrame("Formulário Livro");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Container "Pesquisar Livro"
        JPanel panelPesquisar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        TitledBorder tituloPesquisar = new TitledBorder("Pesquisar Livros");
        panelPesquisar.setBorder(tituloPesquisar);
        JLabel labelNome = new JLabel("Nome:");
        JTextField inputNome = new JTextField(50);
        JButton btnPesquisar = new JButton("Pesquisar");

        // Aumentando a largura do botão Pesquisar
        Dimension btnSize = btnPesquisar.getPreferredSize();
        btnPesquisar.setPreferredSize(new Dimension(120, 40));

        // Ajustando a borda do botão Pesquisar
        Border line = BorderFactory.createLineBorder(Color.LIGHT_GRAY, 2); // Borda de linha azul com 2 pixels de largura
        Border margin = BorderFactory.createEmptyBorder(5, 15, 5, 15); // Margens ao redor do botão
        btnPesquisar.setBorder(BorderFactory.createCompoundBorder(line, margin));


        panelPesquisar.add(labelNome);
        panelPesquisar.add(inputNome);
        panelPesquisar.add(btnPesquisar);
        frame.add(panelPesquisar, BorderLayout.NORTH);

        // Grid de clientes
        String[] colunas = {"ID", "Nome", "Autor", "Edição", "Ano", "Disponibilidade"};
        DefaultTableModel model = new DefaultTableModel(colunas, 0);
        JTable tabelaLivros = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(tabelaLivros);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Container "Dados dos Livros" usando GridBagLayout
        JPanel panelDados = new JPanel(new GridLayout(6, 2));
        TitledBorder tituloDados = new TitledBorder("Dados Livros");
        panelDados.setBorder(tituloDados);


        lblAno = new JLabel("Ano");
        lblExemplar = new JLabel("Exemplar");
        lblDisponibilidade = new JLabel("Disponbilidade");
        lblEdicao = new JLabel("Edição");
        lblID = new JLabel("ID");
        lblAutor = new JLabel("Autor");

        txtID = new JTextField();
        txtExemplar = new JTextField();
        txtAutor = new JTextField();
        txtEdicao = new JTextField();
        txtAno = new JTextField();
        txtDisponibilidade = new JTextField();

        panelDados.add(lblID);
        panelDados.add(txtID);
        panelDados.add(lblExemplar);
        panelDados.add(txtExemplar);
        panelDados.add(lblAutor);
        panelDados.add(txtAutor);
        panelDados.add(lblEdicao);
        panelDados.add(txtEdicao);
        panelDados.add(lblAno);
        panelDados.add(txtAno);
        panelDados.add(lblDisponibilidade);
        panelDados.add(txtDisponibilidade);



        // Botões à direita do formulário
        JPanel panelBotoes = new JPanel(new GridLayout(5, 1));
        TitledBorder tituloBotoes = new TitledBorder(" ");
        panelBotoes.setBorder(tituloBotoes);

        btnCadastrar = new JButton("Cadastrar");
        btnExcluir = new JButton("Excluir");
        btnNovo = new JButton("Novo");
        btnSair = new JButton("Sair");
        btnAlterar = new JButton("Alterar");

        btnCadastrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    Livro livro = new Livro();
                    livro.setExemplar((txtExemplar.getText()));
                    livro.setAutor((txtAutor.getText()));
                    livro.setEdicao((Byte.valueOf(txtEdicao.getText())));
                    livro.setAno((Short.valueOf(txtAno.getText())));
                    livro.setDisponibilidade((txtDisponibilidade.getText()));


                    BdLivro l = new BdLivro();
                    JOptionPane.showMessageDialog(null, "Dados cadastrado com sucesso");
                    limpaCampos();
                    desabilitaCampos();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao cadastrar Dados");
                }
            }
        });//fim botão cadastrar

        btnNovo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                habilitaCampos();
            }
        });//fim do botão novo

        panelBotoes.add(btnCadastrar);
        panelBotoes.add(btnExcluir);
        panelBotoes.add(btnNovo);
        panelBotoes.add(btnSair);
        panelBotoes.add(btnAlterar);

        JPanel panelFormulario = new JPanel(new BorderLayout());
        panelFormulario.add(panelDados, BorderLayout.CENTER);
        panelFormulario.add(panelBotoes, BorderLayout.EAST);

        frame.add(panelFormulario, BorderLayout.SOUTH);

        frame.setVisible(true);

    }//fim do construtor

    private void limpaCampos(){
        txtID.setText("");
        txtExemplar.setText("");
        txtEdicao.setText("");
        txtAno.setText("");
        txtAutor.setText("");
        txtDisponibilidade.setText("");
    } //fim do limpa campos

    private void desabilitaCampos(){
        txtID.setEditable(false);
        txtExemplar.setEditable(false);
        txtEdicao.setEditable(false);
        txtAno.setEditable(false);
        txtAutor.setEditable(false);
        txtDisponibilidade.setEditable(false);
    } //fim do desabilita campos

    private void habilitaCampos(){
        txtID.setEditable(true);
        txtExemplar.setEditable(true);
        txtEdicao.setEditable(true);
        txtAno.setEditable(true);
        txtAutor.setEditable(true);
        txtDisponibilidade.setEditable(true);
    } //fim da habilita campos

} //fim da classe
