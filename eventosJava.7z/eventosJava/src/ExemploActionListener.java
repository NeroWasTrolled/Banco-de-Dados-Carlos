import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ExemploActionListener implements ActionListener {
    JTextField tf = new JTextField();
    JButton b = new JButton();
    public ExemploActionListener() {
        JFrame f = new JFrame("Exemplo de ActionListener");
        f.setSize(400,400);
        b.setText("Clique aqui!");

        b.addActionListener(this);

        tf.setBounds(50,50,150,20);
        b.setBounds(50,100,100,30);

        f.add(tf);
        f.add(b);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        tf.setText("O botão foi clicado!");
    }
}
